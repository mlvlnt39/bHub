<?php




function pix_templates_miscellaneous(){
    $templates = array();

    // event

//     $data = array(); // Create new array
//     $data['name'] = __( 'Schedule Event', 'essentials-core' ); // Assign name for your custom template
//     $data['weight'] = 0; // Weight of your template in the template list
//     $data['type'] = 'default_templates'; // Weight of your template in the template list
//     $data['category'] = 'default_templates'; // Weight of your template in the template list
//     $data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'thumbnails/video/event-schedule.png', __FILE__ ) );
//     $data['custom_class'] = 'custom_template_for_vc_custom_template all'; // CSS class name
//     $data['content']  = <<<CONTENT
// [vc_section full_width="stretch_row" css=".vc_custom_1590468534637{padding-top: 80px !important;padding-bottom: 80px !important;background-color: #f8f9fa !important;}" el_id="pix_section_program"][vc_row full_width="stretch_row"][vc_column content_align="text-center" offset="vc_col-md-offset-1 vc_col-md-10"][pix_badge bold="font-weight-bold" secondary_font="" text_color="white" bg_color="secondary" text_size="custom" style="" hover_effect="" add_hover_effect="" animation="fade-in-up" padding="" text="Create and Share Events" css=".vc_custom_1590468336677{margin-bottom: 15px !important;padding-top: 9px !important;padding-right: 15px !important;padding-bottom: 8px !important;padding-left: 15px !important;}" delay="300" text_custom_size="14px"][sliding-text bold="font-weight-bold" secondary_font="secondary-font" position="center" size="h2" text_color="heading-default"]Event Schedule[/sliding-text][pix_text size="text-18" content_color="body-default" position="text-center" animation="fade-in-up" delay="600" max_width="600px"]Combine seamlessly fitting layouts, customize everything you want, switch components on the go using our page builder.[/pix_text][content_box style="3" hover_effect="3" add_hover_effect="" animation="" css=".vc_custom_1590465411507{margin-top: 40px !important;margin-bottom: 40px !important;padding-top: 30px !important;padding-right: 30px !important;padding-bottom: 30px !important;padding-left: 30px !important;background-color: #ffffff !important;}"][pix_event content_color="heading-default" features="%5B%7B%22time%22%3A%229%3A00%20-%2011%3A00%22%2C%22title%22%3A%22Introduction%20to%20Essentials%22%2C%22text%22%3A%22Discover%20all%20available%20features%22%7D%2C%7B%22time%22%3A%2211%3A00%20-%2012%3A30%22%2C%22title%22%3A%22Workshop%22%2C%22text%22%3A%22Learn%20how%20to%20build%20a%20stunning%20website%22%7D%2C%7B%22time%22%3A%2212%3A30%20-%2014%3A00%22%2C%22title%22%3A%22Lunch%20break%22%2C%22text%22%3A%22Taste%20free%20delicious%20French%20food%20%22%7D%2C%7B%22time%22%3A%2214%3A00%20-%2016%3A00%22%2C%22title%22%3A%22Design%20conference%22%2C%22text%22%3A%22Learn%20how%20we%20created%20Essentials%20theme%22%7D%2C%7B%22time%22%3A%2216%3A00%20-%2018%3A00%22%2C%22title%22%3A%22Code%20session%22%2C%22text%22%3A%22Make%20your%20own%20website%22%7D%5D" animation="fade-in-up"][/content_box][pix_button btn_text="Reserve your seat" btn_size="md" btn_effect="2" btn_hover_effect="2" btn_add_hover_effect="" btn_icon_animation="yes" btn_animation="fade-in-up" btn_icon="pixicon-ticket-2" btn_anim_delay="800" css=".vc_custom_1590465438168{margin-top: 10px !important;}" btn_link="#"][/vc_column][/vc_row][/vc_section]
// CONTENT;
//
//     array_push($templates, $data);

    return $templates;
}




 ?>
